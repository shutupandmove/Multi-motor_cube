#ifndef _STEPMOTOR_H_
#define _STEPMOTOR_H_

#include <Arduino.h>

//步进电机类设置为StepMotor
class StepMotor{
  public:
    StepMoter();
    void set_enpin(int user_enpin,int pin_state);//设置使能引脚在UNO板上的端口和状态
    void set_dirpin(int user_dirpin,int pin_state);//设置方向引脚
    void set_steppin(int user_steppin,int pin_state);//设置步进引脚
    void motor_rot(int user_pulsenum,int time_1,int time_2);//设置电机转动的脉冲信号，控制转动角度和速度
    
  private:
  //tmc2225驱动板需要UNO板直接输入使能、方向和步进信号，此处变量做控制用
    int enpin;//使能引脚 LOW_ON HIGH_OFF
    int dirpin;//方向引脚 change direction
    int steppin;//步进引脚 HIGH > LOW:1 step
};

#endif
